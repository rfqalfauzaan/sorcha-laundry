import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color.fromRGBO(27, 8, 138, 1);
}
