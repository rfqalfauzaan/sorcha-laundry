import 'package:flutter_riverpod/flutter_riverpod.dart';

final dashboardNavIndexProvider = StateProvider.autoDispose((ref) => 0);
