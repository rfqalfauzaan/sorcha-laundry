import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:sorcha_laundry/models/laundry_model.dart';

import '../models/user_model.dart';

class AppSession {
  static Future<UserModel?> getUser() async {
    final pref = await SharedPreferences.getInstance();
    String? userString = pref.getString('user');
    if (userString == null) return null;

    var userMap = jsonDecode(userString);
    return UserModel.fromJson(userMap);
  }

  static Future<bool> setUser(Map userMap) async {
    final pref = await SharedPreferences.getInstance();
    String userString = jsonEncode(userMap);
    bool success = await pref.setString('user', userString);
    return success;
  }

  static Future<bool> removeUser() async {
    final pref = await SharedPreferences.getInstance();
    bool success = await pref.remove('user');
    return success;
  }

  static Future<String?> getBearerToken() async {
    final pref = await SharedPreferences.getInstance();
    String? token = pref.getString('bearer_token');
    return token;
  }

  static Future<bool> setBearerToken(String bearerToken) async {
    final pref = await SharedPreferences.getInstance();
    bool success = await pref.setString('bearer_token', bearerToken);
    return success;
  }

  static Future<bool> removeBearerToken() async {
    final pref = await SharedPreferences.getInstance();
    bool success = await pref.remove('bearer_token');
    return success;
  }

   static Future<LaundryModel?> getlaundry(result) async {
    final pref = await SharedPreferences.getInstance();
    String? laundryString = pref.getString('laundry');
    if (laundryString == null) return null;

    var userMap = jsonDecode(laundryString);
    return LaundryModel.fromJson(userMap);
  }
}
