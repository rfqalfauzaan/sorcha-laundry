package com.example.sorcha_laundry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
